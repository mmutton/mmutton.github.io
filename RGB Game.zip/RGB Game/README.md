# Red Green Blue (rgb) Game

Basic javascript project with random number creator for rgb(x, y, z) color values.  
CSS and Javascript styling.

![RGB Game](images/rgbGameScreenshot.png);